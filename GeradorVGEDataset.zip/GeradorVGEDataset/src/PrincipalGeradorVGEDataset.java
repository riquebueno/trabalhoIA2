
import java.util.ArrayList;

public class PrincipalGeradorVGEDataset {

	public static void main(String[] args) {
	
		//leitura das linhas do arquivo com o schema da base
		String nomeArquivo = "schemaDatabase.csv";
		ProcessadorDeArquivo processadorDeArquivo = new ProcessadorDeArquivo();
		ArrayList<Linha> linhas = processadorDeArquivo.processaArquivo(nomeArquivo);
	
		//gera as queries
		//GeradorDeQueries geradorDeQueries = new GeradorDeQueries();
		
		
		
		
		
		
	
	}//fim main



}//fim class
