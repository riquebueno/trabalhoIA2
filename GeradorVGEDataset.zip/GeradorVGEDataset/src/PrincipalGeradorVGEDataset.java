
import java.util.ArrayList;

public class PrincipalGeradorVGEDataset {

	public static void main(String[] args) {
	
		//leitura das linhas do arquivo com o schema da base
		String nomeArquivo = "schemaDatabase.csv";
		ProcessadorDeArquivo processadorDeArquivo = new ProcessadorDeArquivo();
		ArrayList<Linha> linhas = processadorDeArquivo.processaArquivo(nomeArquivo);
	
		//gera as queries
		GeradorDeQueries geradorDeQueries = new GeradorDeQueries();
		
		Conceito conceito = new Conceito(1, "Pa�s", null);
		int numeroDeAtributosClausulaSelect=-1;//falta corrigir
		int numeroDeRestricoesClausulaWhere=-1;//falta corrigir
		ArrayList<ComandoSQL> comandos = geradorDeQueries.geraConjuntoSQLComClausulasIndependentesDadoUmConceito(conceito, 
																												linhas, 
																												numeroDeAtributosClausulaSelect, 
																												numeroDeRestricoesClausulaWhere);
		
		for(int i=0;i<comandos.size();i++){
			ComandoSQL comandoSQL = comandos.get(i);
			System.out.println(comandoSQL.getComando());
		}
	
		System.out.println(comandos.size());
		
	}//fim main



}//fim class
