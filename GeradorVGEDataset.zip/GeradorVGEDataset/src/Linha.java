
public class Linha {

	private int codConceito;
	private String nomeConceito;
	private int codAtributo;
	private String nomeAtributo;
	private int codTipoAtributo;
	private String nomeTipoAtributo;
	private int codTipoOperador;
	private String nomeTipoOperador;
	
	public Linha(int codConceito,String nomeConceito,int codAtributo,String nomeAtributo,
				int codTipoAtributo,String nomeTipoAtributo,int codTipoOperador,String nomeTipoOperador){
		this.codConceito=codConceito;
		this.nomeConceito=nomeConceito;
		this.codAtributo=codAtributo;
		this.nomeAtributo=nomeAtributo;
		this.codTipoAtributo=codTipoAtributo;
		this.nomeTipoAtributo=nomeTipoAtributo;
		this.codTipoOperador=codTipoOperador;
		this.nomeTipoOperador=nomeTipoOperador;
	}
	
	public int getCodConceito() {
		return codConceito;
	}
	public void setCodConceito(int codConceito) {
		this.codConceito = codConceito;
	}
	public String getNomeConceito() {
		return nomeConceito;
	}
	public void setNomeConceito(String nomeConceito) {
		this.nomeConceito = nomeConceito;
	}
	public int getCodAtributo() {
		return codAtributo;
	}
	public void setCodAtributo(int codAtributo) {
		this.codAtributo = codAtributo;
	}
	public String getNomeAtributo() {
		return nomeAtributo;
	}
	public void setNomeAtributo(String nomeAtributo) {
		this.nomeAtributo = nomeAtributo;
	}
	public int getCodTipoAtributo() {
		return codTipoAtributo;
	}
	public void setCodTipoAtributo(int codTipoAtributo) {
		this.codTipoAtributo = codTipoAtributo;
	}
	public String getNomeTipoAtributo() {
		return nomeTipoAtributo;
	}
	public void setNomeTipoAtributo(String nomeTipoAtributo) {
		this.nomeTipoAtributo = nomeTipoAtributo;
	}
	public int getCodTipoOperador() {
		return codTipoOperador;
	}
	public void setCodTipoOperador(int codTipoOperador) {
		this.codTipoOperador = codTipoOperador;
	}
	public String getNomeTipoOperador() {
		return nomeTipoOperador;
	}
	public void setNomeTipoOperador(String nomeTipoOperador) {
		this.nomeTipoOperador = nomeTipoOperador;
	}
	
	
	
	
	
	
}
