
public class Atributo {

	private int codigo;
	private String nome;
	private TipoAtributo tipoAtributo;
	private Conceito conceito;
	
	public Atributo(int codigo, String nome, TipoAtributo tipoAtributo,Conceito conceito){
		this.codigo=codigo;
		this.nome=nome;
		this.tipoAtributo=tipoAtributo;
		this.conceito=conceito;
	}
	
	public Conceito getConceito() {
		return conceito;
	}

	public void setConceito(Conceito conceito) {
		this.conceito = conceito;
	}

	public TipoAtributo getTipoAtributo() {
		return tipoAtributo;
	}

	public void setTipoAtributo(TipoAtributo tipoAtributo) {
		this.tipoAtributo = tipoAtributo;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	
}
