import java.util.ArrayList;

public class Utilitario {

	private ArrayList<Linha> linhas;
	
	public Utilitario(ArrayList<Linha> linhas){
		this.linhas = linhas;
	}
	
	public ArrayList<Linha> getLinhas(){
		return linhas;
	}
	
	//metodo que recebe um Atributo e pesquisa dentro de linhas quais s�o os poss�veis TipoOperador que ele aceita
	ArrayList<TipoOperador> recuperaTipoOperadorDadoUmAtributo(Atributo atributo){
		ArrayList<TipoOperador> listaTipoOperador = new ArrayList<TipoOperador>();
		
		IMPLEMENTA��O PENDENTE
		
		return listaTipoOperador;		
	}
	
	//metodo que recebe um Conceito e pesquisa dentro de linhas quais s�o os Atributo ele ele tem
	ArrayList<Atributo> recuperaAtributosDadoUmConceito(Conceito conceito){
		ArrayList<Atributo> listaDeAtributos = new ArrayList<Atributo>();
		
		IMPLEMENTA��O PENDENTE
		
		return listaDeAtributos;
	}
	
	
	
}
