import java.util.ArrayList;

public class Utilitario {

	private ArrayList<Linha> linhas;
	
	public Utilitario(ArrayList<Linha> linhas){
		this.linhas = linhas;
	}
	
	public ArrayList<Linha> getLinhas(){
		return linhas;
	}
	
	//metodo que recebe um Atributo e pesquisa dentro de linhas quais s�o os poss�veis TipoOperador que ele aceita
	ArrayList<TipoOperador> recuperaTipoOperadorDadoUmAtributo(Atributo atributo){
		ArrayList<TipoOperador> listaTipoOperador = new ArrayList<TipoOperador>();
		
		IMPLEMENTA��O PENDENTE
		
		return listaTipoOperador;		
	}
	
}
