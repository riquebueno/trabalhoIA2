import java.util.ArrayList;
import java.util.Arrays;

public class Utilitario {

	private ArrayList<Linha> linhas;
	
	public Utilitario(ArrayList<Linha> linhas){
		this.linhas = linhas;
	}
	
	public ArrayList<Linha> getLinhas(){
		return linhas;
	}
	
	//� preciso corrigir esse m�todo-------------
	public Object recuperaValor1(TipoAtributo tipoAtributo){
		//Configura��o das constantes - � preciso alterar esses valores ....
		String VALOR_DATA1="10/10/2008";
		String VALOR_DATA2="10/10/2016";
		float VALOR_NUMERO1=55;
		float VALOR_NUMERO2=864;
		String VALOR_TEXTO1="RJS";
		String VALOR_TEXTO2="def";
		
		int codTipoAtributo = tipoAtributo.getCodigo();
		if(codTipoAtributo==1){
			//numero	
			return (Object)VALOR_NUMERO1;
		}
		else if(codTipoAtributo==2){
			//string
			return (Object)VALOR_TEXTO1;
		}
		else if(codTipoAtributo==3){
			//data
			return (Object)VALOR_DATA1;
		}
		return null;
	}
	
	//metodo que recebe um Atributo e pesquisa dentro de linhas quais s�o os poss�veis TipoOperador que ele aceita
	private ArrayList<TipoOperador> recuperaTipoOperadorDadoUmAtributo(Atributo atributo){
		ArrayList<TipoOperador> listaTipoOperador = null;
		
		//descubro qual o TipoAtributo do atributo
		TipoAtributo tipoAtributo = atributo.getTipoAtributo();		
		
		//busco os TipoOperador que o TipoAtributo aceita
		listaTipoOperador = recuperaListaTipoOperadorDadoUmTipoAtributo(tipoAtributo);
						
		return listaTipoOperador;		
	}
	
	//metodo que recebe um Conceito e pesquisa dentro de linhas quais s�o os Atributo ele ele tem
	public ArrayList<Atributo> recuperaAtributosDadoUmConceito(int codConceito, ArrayList<Linha> linhas){
		ArrayList<Atributo> listaDeAtributos = new ArrayList<Atributo>();
		
		for(int i=0;i<linhas.size();i++){
			Linha linha = linhas.get(i);
			if(linha.getCodConceito()==codConceito){
				int codAtributoDaLinha = linha.getCodAtributo();
				if(!existeEsseAtributoNoArray(codAtributoDaLinha,listaDeAtributos)){
		
					//crio o Atributo
					TipoAtributo tipoAtributo = new TipoAtributo(linha.getCodTipoAtributo(), linha.getNomeTipoAtributo());
					Conceito conceito =  new Conceito(linha.getCodConceito(), linha.getNomeConceito(), null);
					Atributo atributo = new Atributo(linha.getCodAtributo(), linha.getNomeAtributo(), tipoAtributo, conceito);
					
					//guardo o Atributo na lista
					listaDeAtributos.add(atributo);
				}
			}
		}		
		return listaDeAtributos;
	}
	
	//metodo qie pesquisa dentro de linhas quais s�o os Conceitos
	public ArrayList<Conceito> recuperaConceitos(ArrayList<Linha> linhas){
		ArrayList<Conceito> listaDeConceitos = new ArrayList<Conceito>();
		
		for(int i=0;i<linhas.size();i++){
			Linha linha = linhas.get(i);
			
			int codConceitoDaLinha = linha.getCodConceito();
			if(!existeEsseConceitoNoArray(codConceitoDaLinha,listaDeConceitos)){
	
				//crio o Conceito
				ArrayList<Atributo> listaDeAtributos = recuperaAtributosDadoUmConceito(linha.getCodConceito(), linhas);
				Conceito conceito = new Conceito(linha.getCodConceito(), linha.getNomeConceito(), listaDeAtributos);
				
				//guardo o Conceito na lista
				listaDeConceitos.add(conceito);
			}
			
		}		
		return listaDeConceitos;
	}
	
	
	//metodo que verifica se j� existe um atributo com o c�digo codAtributoDaLinha dentro da listaDeAtributos 
	private boolean existeEsseAtributoNoArray(int codAtributoDaLinha,ArrayList<Atributo> listaDeAtributos){
		boolean achou = false;
		
		for(int i=0;i<listaDeAtributos.size();i++){
			if(listaDeAtributos.get(i).getCodigo()==codAtributoDaLinha){
				achou=true;
				break;
			}
		}
		
		return achou;
	}
	
	//metodo que verifica se j� existe um conceito com o c�digo codConceito dentro da listaDeConceitos 
	private boolean existeEsseConceitoNoArray(int codConceitoDaLinha,ArrayList<Conceito> listaDeConceitos){
		boolean achou = false;
		
		for(int i=0;i<listaDeConceitos.size();i++){
			if(listaDeConceitos.get(i).getCodigo()==codConceitoDaLinha){
				achou=true;
				break;
			}
		}
		
		return achou;
	}
	
	//metodo que cria a lista de tipos de operadores que existem
	private ArrayList<TipoOperador> geraTiposDeOperadores(){
		
		TipoOperador to1 = new TipoOperador(1, "EQUAL", true, false);
		TipoOperador to2 = new TipoOperador(2, "NOT_EQUAL", true, false);
		TipoOperador to3 = new TipoOperador(3, "LESS", true, false);
		TipoOperador to4 = new TipoOperador(4, "GREATER", true, false);
		TipoOperador to5 = new TipoOperador(5, "LESS_OR_EQUAL", true, false);
		TipoOperador to6 = new TipoOperador(6, "GREATER_OR_EQUAL", true, false);
		TipoOperador to7 = new TipoOperador(7, "BETWEEN", false, true);
		TipoOperador to8 = new TipoOperador(8, "NULL", false, false);
		TipoOperador to9 = new TipoOperador(9, "NOT NULL", false, false);
		TipoOperador to10 = new TipoOperador(10, "LIKE", true, false);
		TipoOperador to11 = new TipoOperador(11, "NOT LIKE", true, false);
		
		ArrayList<TipoOperador> listaDeTiposOperadores = new ArrayList<TipoOperador>();
		listaDeTiposOperadores.add(to1);
		listaDeTiposOperadores.add(to2);
		listaDeTiposOperadores.add(to3);
		listaDeTiposOperadores.add(to4);
		listaDeTiposOperadores.add(to5);
		listaDeTiposOperadores.add(to6);
		listaDeTiposOperadores.add(to7);
		listaDeTiposOperadores.add(to8);
		listaDeTiposOperadores.add(to9);
		listaDeTiposOperadores.add(to10);
		listaDeTiposOperadores.add(to11);
		
		return listaDeTiposOperadores;
	}
	
	public TipoOperador recuperaTipoOperadorDadoCodigo(int codTipoOperador){
		ArrayList<TipoOperador> listaTipoOperador = this.geraTiposDeOperadores();
		for(int i=0;i<listaTipoOperador.size();i++){
			TipoOperador tipoOperador = listaTipoOperador.get(i);
			if(tipoOperador.getCodigo()==codTipoOperador){
				return tipoOperador;
			}
		}
		return null;
	}
		
	//metodo que recupera uma lista de objetos do tipo TipoOperador (Ex: maior, menor, etc) a partir de um objeto TipoAtributo (Ex: string, n�mero, etc)
	public ArrayList<TipoOperador> recuperaListaTipoOperadorDadoUmTipoAtributo(TipoAtributo tipoAtributo){
		ArrayList<TipoOperador> listaTipoOperador = new ArrayList<TipoOperador>();
		ArrayList<Integer> listaCodTipoOperadorTemp = null;
		
		int codTipoAtributo = tipoAtributo.getCodigo();
		
		//mapeamento dos TipoOperador que s�o aceitos por cada TipoAtributo
		if(codTipoAtributo==1){
			listaCodTipoOperadorTemp = new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9));
		}
		else if(codTipoAtributo==2){
			listaCodTipoOperadorTemp = new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9,10,11));
		}
		else if(codTipoAtributo==3){
			listaCodTipoOperadorTemp = new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9));
		}
		else if(codTipoAtributo==4){
			listaCodTipoOperadorTemp = new ArrayList<>(Arrays.asList(1,2,8,9));
		}
		
		//processo a lista de c�digos de tipos de operadores para criar uma lista de TipoOperador
		for(int i=0;i<listaCodTipoOperadorTemp.size();i++){
			int codTipoOperador = listaCodTipoOperadorTemp.get(i);
			TipoOperador tipoOperador = recuperaTipoOperadorDadoCodigo(codTipoOperador);
			listaTipoOperador.add(tipoOperador);
		}
		
		return listaTipoOperador;
	}
	
	
	
	
	

	
	
}
