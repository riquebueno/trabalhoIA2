import java.util.ArrayList;

public class Conceito {

	private int codigo;
	private String nome;
	private ArrayList<Atributo> atributos;
	
	public Conceito(int codigo, String nome, ArrayList<Atributo> atributos){
		this.codigo=codigo;
		this.nome=nome;
		this.atributos = atributos;
	}

	public ArrayList<Atributo> getAtributos() {
		return atributos;
	}

	public void setAtributos(ArrayList<Atributo> atributos) {
		this.atributos = atributos;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
}
