import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class ProcessadorDeArquivo {

	public ArrayList<Linha> processaArquivo(String nomeDoArquivo){
		
		//Configura��o do arquivo
		String nomeArquivo = nomeDoArquivo;
		File file = new File(nomeArquivo);
		BufferedReader reader = null;
		
		//Leitura do arquivo e armazenamento no array registros. Tudo � armazenado como string
		ArrayList registros = new ArrayList<>();
		try {
		    reader = new BufferedReader(new FileReader(file));
		    String text = null;

		    while ((text = reader.readLine()) != null) {
		    	String[] ar=text.split(";");
		    	registros.add(ar);		        
		    }
		} catch (FileNotFoundException e) {
		    e.printStackTrace();
		} catch (IOException e) {
		    e.printStackTrace();
		} finally {
		    try {
		        if (reader != null) {
		            reader.close();
		        }
		    } catch (IOException e) {
		    }
		}
		
		ArrayList<Linha> linhas = new ArrayList<Linha>();		
		//Vou processar o array registros que est� com todas as informa��es como String		
		//tenho que pular a primeira linha que tem os headers. Por isso i come�a em 1
		for (int i = 1; i < registros.size(); i++) {
			
			//geracao do codConceito
			String texto = ((String[])registros.get(i))[0];
			int codConceito=Integer.parseInt(texto.substring(1, texto.length()-1));
						
			//geracao do nomeConceito
			String nomeConceito=((String[])registros.get(i))[1];
			nomeConceito = nomeConceito.substring(1, nomeConceito.length()-1);
			
			//geracao do codAtributo
			texto = ((String[])registros.get(i))[2];
			int codAtributo=Integer.parseInt(texto.substring(1, texto.length()-1));
			
			//geracao do nomeAtributo
			String nomeAtributo=((String[])registros.get(i))[3];
			nomeAtributo = nomeAtributo.substring(1, nomeAtributo.length()-1);
			
			//geracao do codTipoAtributo
			texto = ((String[])registros.get(i))[4];
			int codTipoAtributo=Integer.parseInt(texto.substring(1, texto.length()-1));
			
			//geracao do nomeTipoAtributo
			String nomeTipoAtributo=((String[])registros.get(i))[5];
			nomeTipoAtributo = nomeTipoAtributo.substring(1, nomeTipoAtributo.length()-1);
			
			//geracao do codTipoOperador
			texto = ((String[])registros.get(i))[6];
			int codTipoOperador=Integer.parseInt(texto.substring(1, texto.length()-1));
			
			//geracao do nomeTipoOperador
			String nomeTipoOperador=((String[])registros.get(i))[7];
			nomeTipoOperador = nomeTipoOperador.substring(1, nomeTipoOperador.length()-1);
			
			Linha linha = new Linha(codConceito, nomeConceito, codAtributo, nomeAtributo, codTipoAtributo, nomeTipoAtributo, codTipoOperador, nomeTipoOperador);
			
			linhas.add(linha);
		}
		return linhas;		
	}
	
	
	
}
