
public class ComandoSQL {

	//� preciso alterar essa classe para criar atributos para cada uma das partes do comando SQL, ao inv�s de 
	//tratar tudo como um �nico string
	
	private String comando;

	public ComandoSQL(String comando){
		this.comando = comando;
	}
	
	public String getComando() {
		return comando;
	}

	public void setComando(String comando) {
		this.comando = comando;
	}
	
	
	
}
