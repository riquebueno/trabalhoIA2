
import java.util.ArrayList;
import java.util.Iterator;

public class GeradorDeQueries {

	
	//� preciso alterar esse m�todo. Atualmente ele est� gerando todas as queries com 1 coluna no SELECT e 1 coluna no WHERE
	
	//recebe uma lista de linhas e gera um conjunto de comandos SQL com as clausulas select e where independentes
	public ArrayList<ComandoSQL> geraConjuntoSQLComClausulasIndependentesDadoUmConceito(Conceito conceito,
																						ArrayList<Linha> linhas, 
																						int numeroDeAtributosClausulaSelect, 
																						int numeroDeRestricoesClausulaWhere){
		ArrayList<ComandoSQL> listaDeComandosSQL = new ArrayList<ComandoSQL>();
				
		Utilitario utilitario = new Utilitario(linhas);
		
		ArrayList<Atributo> listaDeAtributos = utilitario.recuperaAtributosDadoUmConceito(conceito.getCodigo(), linhas);
		
		//vou percorrer a lista de atributos do Conceito conceito
		for(int i=0;i<listaDeAtributos.size();i++){
			Atributo atributo = listaDeAtributos.get(i);
			String consultaSemWhere = "SELECT " + atributo.getNome() + " FROM " + conceito.getNome();
			
			TipoAtributo tipoAtributo = atributo.getTipoAtributo();
			ArrayList<TipoOperador> listaTipoOperador = utilitario.recuperaListaTipoOperadorDadoUmTipoAtributo(tipoAtributo);
			
			//vou percorrer a lista de TipoOperador que o Atributo atributo aceita
			for(int j=0;j<listaTipoOperador.size();j++){
				TipoOperador tipoOperador = listaTipoOperador.get(i);
				boolean aceitaUmOperando = tipoOperador.isAceitaUmOperando();
				boolean aceitaDoisOperandos = tipoOperador.isAceitaDoisOperandos();
				if(aceitaUmOperando){
					Object valor = utilitario.recuperaValor1(tipoAtributo);
					String clausulaWhere = " WHERE " + atributo.getNome() + " " + tipoOperador.getNome() + " " + valor;
					String textoComandoSQL = consultaSemWhere + clausulaWhere;
					ComandoSQL comandoSQL = new ComandoSQL(textoComandoSQL);
					listaDeComandosSQL.add(comandoSQL);
				}
				else{
					//aceita 2 operandos. Ex: between
					
				}
			}
		}
					
		return listaDeComandosSQL;
	}
		
	
	
	
	
}
