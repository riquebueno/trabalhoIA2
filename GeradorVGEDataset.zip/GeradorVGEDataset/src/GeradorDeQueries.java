
import java.util.ArrayList;
import java.util.Iterator;

public class GeradorDeQueries {

	//Configura��o das constantes
	String VALOR_DATA;
	float VALOR_NUMERO;
	String VALOR_TEXTO;
	
	//recebe uma lista de linhas e gera um conjunto de comandos SQL com as clausulas select e where independentes
	public ArrayList<ComandoSQL> geraConjuntoSQLComClausulasIndependentes(ArrayList<Linha> linhas){
		ArrayList<ComandoSQL> listaDeComandosSQL = new ArrayList<ComandoSQL>();
		for(int i=0;i<linhas.size();i++){
	
			
			PROBLEMA!!! N�O FAZ SENTIDO PASSAR UMA �NICA LINHA PARA A GERA��O DE UMA QUERY SQL
			
			PENSAR EM COMO COMBINAR A QTD DE LINHAS ....
			
			
			ComandoSQL comandoSQL = this.geraSQLComClausulasIndependentes(linhas.get(i));
			listaDeComandosSQL.add(comandoSQL);
			
			
			
		}
					
		return listaDeComandosSQL;
	}
		
	
	
	
	
}
