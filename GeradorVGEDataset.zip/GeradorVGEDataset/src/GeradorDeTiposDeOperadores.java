import java.util.ArrayList;

public class GeradorDeTiposDeOperadores {

	
	public ArrayList<TipoOperador> geraTiposDeOperadores(){
		
		TipoOperador to1 = new TipoOperador(1, "EQUAL");
		TipoOperador to2 = new TipoOperador(2, "NOT_EQUAL");
		TipoOperador to3 = new TipoOperador(3, "LESS");
		TipoOperador to4 = new TipoOperador(4, "GREATER");
		TipoOperador to5 = new TipoOperador(5, "LESS_OR_EQUAL");
		TipoOperador to6 = new TipoOperador(6, "GREATER_OR_EQUAL");
		TipoOperador to7 = new TipoOperador(7, "BETWEEN");
		TipoOperador to8 = new TipoOperador(8, "NULL");
		TipoOperador to9 = new TipoOperador(9, "NOT NULL");
		TipoOperador to10 = new TipoOperador(10, "LIKE");
		TipoOperador to11 = new TipoOperador(11, "NOT LIKE");
		
		ArrayList<TipoOperador> listaDeTiposOperadores = new ArrayList<TipoOperador>();
		listaDeTiposOperadores.add(to1);
		listaDeTiposOperadores.add(to2);
		listaDeTiposOperadores.add(to3);
		listaDeTiposOperadores.add(to4);
		listaDeTiposOperadores.add(to5);
		listaDeTiposOperadores.add(to6);
		listaDeTiposOperadores.add(to7);
		listaDeTiposOperadores.add(to8);
		listaDeTiposOperadores.add(to9);
		listaDeTiposOperadores.add(to10);
		listaDeTiposOperadores.add(to11);
		
		return listaDeTiposOperadores;
	}
	
}
